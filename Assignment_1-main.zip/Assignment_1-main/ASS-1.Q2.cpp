#include <iostream>
using namespace std;
int main()
{
cout<<"Print the ASCII value of character ‘U’.";
cout<<"\nAns : \n";
int x='U';
cout<<"the ASCII value of character ‘U’ is : "<<x;
    return 0;
}