#include <iostream>
using namespace std;
int main()
{
    cout << "Write a C++ program to calculate the cube of a number.";
    cout << "\nAns : \n";
    int a, b;
    cout << "Enter a number :";
    cin >> a;
    b = a * a * a;
    cout << "The cube of the number is : " << b;
    return 0;
}