#include <iostream>
using namespace std;
int main()
{
    cout << "Take 2 integer values in two variables x and y and print their product ?";
    cout << "\nAns : \n";
    int x, y, p;
    cout << "Enter two number to find their product.\n";
    cin >> x >> y;
    p = x * y;
    cout << "The product of the given two number is : " << p;

    return 0;
}